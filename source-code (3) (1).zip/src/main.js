import { Actor } from 'apify';
import { PlaywrightCrawler } from 'crawlee';

Actor.main(async () => {
    const input = await Actor.getInput();
    const { username, password } = input;

    const crawler = new PlaywrightCrawler({
        maxRequestsPerCrawl: 1,
        async requestHandler({ page }) {
            // 1) Go to Skool login page
            await page.goto('https://www.skool.com/login', {
                waitUntil: 'domcontentloaded',
            });

            // 2) Fill in the login form
            await page.fill('#email', username);
            await page.fill('#password', password);

            // 3) Wait for the login button to be enabled (i.e., not disabled)
            await page.waitForSelector('button[type="submit"]:not([disabled])', { timeout: 30000 });

            // 4) Click the login button and wait for navigation (adjust if navigation doesn't occur)
            await Promise.all([
                page.click('button[type="submit"]'),
                page.waitForNavigation({ waitUntil: 'domcontentloaded' }),
            ]);

            // Alternatively, if the login does not trigger a full navigation, wait for a specific post-login element:
            // await page.waitForSelector('.logged-in-indicator', { timeout: 30000 });

            // 5) Grab cookies
            const cookies = await page.context().cookies();

            // 6) Push cookies to the default Dataset for later use
            await Actor.pushData({
                timestamp: new Date().toISOString(),
                cookies,
            });
        },
    });

    await crawler.run([{ url: 'https://www.skool.com/login' }]);
    Actor.exit();
});